# -*- coding: utf-8 -*-
"""
Created on Mon Sep 21 11:43:13 2020

@author: xiaoyu.si
"""

"""
Part1. Write a program to do the following requirement.
(a) upside-down lena.bmp
(b) right-side-left lena.bmp
(c) diagonally flip lena.bmp
"""

import cv2
import numpy as np
ori = cv2.imread('.\lena.bmp') # original image (512,512,3)

# Upside-down 上下鏡像
up_down = np.copy(ori)
up_down = up_down[::-1,:,:]
cv2.imwrite('up_down_lena.bmp',up_down)


# Right-side-left 左右鏡像
right_left = np.copy(ori)
right_left = right_left[:,::-1,:]
cv2.imwrite('right_left_lena.bmp',right_left)


# diagonally filp 對角線翻轉
diag = np.copy(ori)
diag = diag.transpose((1,0,2))
cv2.imwrite('diagonal_lena.bmp',diag)

'''
#2. Write a program or use software to do the following requirement.
(d) rotate lena.bmp 45 degrees clockwise
(e) shrink lena.bmp in half 
(f) binarize lena.bmp at 128 to get a binary image

'''
#Rotate 45 degrees clockwise
rows,cols = ori.shape[0],ori.shape[1]
M = cv2.getRotationMatrix2D((cols/2,rows/2),-45,1)
rotate = cv2.warpAffine(ori,M,(cols,rows))
cv2.imwrite('rotate_lena.bmp',rotate)

#shrink lena.bmp in half
half = cv2.resize(ori,(0, 0), fx=0.5, fy=0.5,interpolation=cv2.INTER_NEAREST)
cv2.imwrite('half_lena.bmp',half)

#binary image
gray_img = cv2.cvtColor(ori, cv2.COLOR_BGR2GRAY)
ret, thresh = cv2.threshold(gray_img, 128, 255,cv2.THRESH_BINARY)
cv2.imwrite('binary_lena.jpg', thresh)